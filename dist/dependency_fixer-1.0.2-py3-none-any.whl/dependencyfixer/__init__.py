from .dependencyfixer import fix
__version__ = "1.0.2"